var structarm__lms__instance__q31 =
[
    [ "mu", "structarm__lms__instance__q31.html#acb6ca9996b3c5f740d5d6c8e9f4f1d46", null ],
    [ "numTaps", "structarm__lms__instance__q31.html#ac0d84f7d054555931ef8a62511fbcb8a", null ],
    [ "pCoeffs", "structarm__lms__instance__q31.html#a4afe56e991a5416adfd462aa88bda500", null ],
    [ "postShift", "structarm__lms__instance__q31.html#a4705a8f0011bb9166e09bf5bd51e595e", null ],
    [ "pState", "structarm__lms__instance__q31.html#a206d47b49de6f357f933ebe61520753c", null ]
];