var group___s_t_d =
[
    [ "arm_std_f32", "group___s_t_d.html#ga4969b5b5f3d001377bc401a3ee99dfc2", null ],
    [ "arm_std_q15", "group___s_t_d.html#gaf9d27afa9928ff28a63cd98ea9218a72", null ],
    [ "arm_std_q31", "group___s_t_d.html#ga39495e74f96116178be085c9dc7742f5", null ]
];