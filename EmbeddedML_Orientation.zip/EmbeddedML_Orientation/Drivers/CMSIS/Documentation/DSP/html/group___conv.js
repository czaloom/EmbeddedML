var group___conv =
[
    [ "arm_conv_f32", "group___conv.html#ga3f860dc98c6fc4cafc421e4a2aed3c89", null ],
    [ "arm_conv_fast_opt_q15", "group___conv.html#gaf16f490d245391ec18a42adc73d6d749", null ],
    [ "arm_conv_fast_q15", "group___conv.html#gad75ca978ce906e04abdf86a8d76306d4", null ],
    [ "arm_conv_fast_q31", "group___conv.html#ga51112dcdf9b3624eb05182cdc4da9ec0", null ],
    [ "arm_conv_opt_q15", "group___conv.html#gac77dbcaef5c754cac27eab96c4753a3c", null ],
    [ "arm_conv_opt_q7", "group___conv.html#ga4c7cf073e89d6d57cc4e711f078c3f68", null ],
    [ "arm_conv_q15", "group___conv.html#gaccd6a89b0ff7a94df64610598e6e6893", null ],
    [ "arm_conv_q31", "group___conv.html#ga946b58da734f1e4e78c91fcaab4b12b6", null ],
    [ "arm_conv_q7", "group___conv.html#gae2070cb792a167e78dbad8d06b97cdab", null ]
];